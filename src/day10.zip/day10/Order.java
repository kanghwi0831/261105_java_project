package day10;

public class Order {
	// 주문 클래스
	// 상품명, 갯수, 가격(판매금액), 총금액(갯수*가격)
	
	// 주문 추가
	private String menu;
	private int count;
	private int price;
	private int totalPrice;
	
	public Order() {
	}
	public void menuPrice(String menu, int price, int count) {
		this.totalPrice = price*count;
	}
	
	// 메뉴판 (메뉴, 가격 출력)
	public void menuList(String[] product) {
		System.out.println(product);
	}
	
}
