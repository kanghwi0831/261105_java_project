package day10;

public class Product {
	// 제품 클래스
	// 판매제품명, 가격
	private String menu;
	private int price;
	private String kimbap;
	private int kimbapPrice;
	private String noodle;
	private int noodlePrice;
	private String menu_1;
	private int menu_1_price;
	private String menu_2;
	private int menu_2_price;

	public Product() {}
	public Product(String menu, int price) {
		this.menu = menu;
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [menu=" + menu + ", price=" + price + "]";
	}

	public String getMenu() {
		return menu;
	}

	public void setMenu(String menu) {
		this.menu = menu;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	public String getKimbap() {
		return kimbap;
	}
	public void setKimbap(String kimbap) {
		this.kimbap = kimbap;
	}
	public int getKimbapPrice() {
		return kimbapPrice;
	}
	public void setKimbapPrice(int kimbapPrice) {
		this.kimbapPrice = kimbapPrice;
	}
	public String getNoodle() {
		return noodle;
	}
	public void setNoodle(String noodle) {
		this.noodle = noodle;
	}
	public int getNoodlePrice() {
		return noodlePrice;
	}
	public void setNoodlePrice(int noodlePrice) {
		this.noodlePrice = noodlePrice;
	}
	public String getMenu_1() {
		return menu_1;
	}
	public void setMenu_1(String menu_1) {
		this.menu_1 = menu_1;
	}
	public int getMenu_1_price() {
		return menu_1_price;
	}
	public void setMenu_1_price(int menu_1_price) {
		this.menu_1_price = menu_1_price;
	}
	public String getMenu_2() {
		return menu_2;
	}
	public void setMenu_2(String menu_2) {
		this.menu_2 = menu_2;
	}
	public int getMenu_2_price() {
		return menu_2_price;
	}
	public void setMenu_2_price(int menu_2_price) {
		this.menu_2_price = menu_2_price;
	}

}
