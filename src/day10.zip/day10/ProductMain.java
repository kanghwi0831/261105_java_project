package day10;

public class ProductMain {

	public static void main(String[] args) {
		// 키오스크
		// product(상품) class : 상품명, 가격(판매금액)
		// order(주문) class : 상품명, 갯수, 가격(판매금액), 금액(갯수*가격)
		// Product[] menu = new Product[5];  // => 상품리스트
		// 임의의 상품을 등록
		// 주문 => order 객체 발생 => Order[] order = new Order[5];
		Order o = new Order();
		Product p = new Product();
		Product[] productArr = new Product[5];
		Order[] orderArr = new Order[5];
		
		p.setMenu_1("김밥");
		p.setMenu_1_price(1500);
		p.setMenu_2("라면");
		p.setMenu_2_price(3000);
		
		int count;
		int price;
		int totalPrice;
		
		for(int i = 0; i < productArr.length; i++) {
			productArr[i] = new Product(p.getMenu_1(), p.getMenu_1_price());
		}
		
		// 1. 전체 제품을 보여주기.
		
		
		
		// 2. 주문 > 제품명, 수량 입력받기.
		// 3. order 객체가 생성하면 => 오더에 추가
		// 4. 반복 주문 => 종료 키워드 따로 생성하여 반복 주문이 가능하도록 한다
		// 5. order => 배열이 다 차면 배열 증가
		// 6. 주문 완료 시 => 영수증 출력 (전체 주문내역 / 총 지불금액)
		
		// ex)
		// 김밥  2(줄)  3000(원) => 6000(원)
		// 라면  3(개)  5000(원) => 15000(원)
		// 사이다 2(개)  500(원) => 1000(원)
		//---------------------------------
		// 총 지불금액 22000

	}

}
