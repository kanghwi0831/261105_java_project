package day06;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Exam03 {

	public static void main(String[] args) {
		// 야구게임
		// 컴퓨터가 랜덤으로 3자리의 숫자를 생성
		Random ran = new Random();
		Scanner scan = new Scanner(System.in);
		// 배열로 저장
		int comArr[] = new int[3];
		// 각 자리의 숫자는 0~9 까지 중 랜덤 숫자 => 중복 불가능
		comArr[0] = ran.nextInt(10);
		comArr[1] = ran.nextInt(10);
		comArr[2] = ran.nextInt(10);
		while (true) {
			if (comArr[0] == comArr[1]) {
				comArr[0] = ran.nextInt(10);
				continue;
			}
			if (comArr[0] == comArr[2]) {
				comArr[0] = ran.nextInt(10);
				continue;
			}
			if (comArr[1] == comArr[2]) {
				comArr[1] = ran.nextInt(10);
				continue;
			} else
				break;
		}

		System.out.println(Arrays.toString(comArr));
// 유저는 3자리를 맞추는 게임
		int userArr[] = new int[3];
		while (true) {
			System.out.print("입력 : ");
			userArr[0] = scan.nextInt();
			userArr[1] = scan.nextInt();
			userArr[2] = scan.nextInt();

			int stCount = 0;
			int blCount = 0;
// 위치와 숫자가 맞으면 strike
			for (int i = 0; i < 3; i++) {
				if (userArr[i] == comArr[i]) {
					stCount++;
				}
			}
// 숫자만 맞으면 ball (숫자는 맞지만 위치가 안 맞을때)
			for (;;) {
				if (userArr[0] == comArr[1]) {
					blCount++;
				}
				if (userArr[0] == comArr[2]) {
					blCount++;
				}
				if (userArr[1] == comArr[0]) {
					blCount++;
				}
				if (userArr[1] == comArr[2]) {
					blCount++;
				}
				if (userArr[2] == comArr[0]) {
					blCount++;
				}
				if (userArr[2] == comArr[1]) {
					blCount++;
				}
				break;
			}

// user : 1 2 3 => 정답!! break;
			if (stCount != 3) {
				System.out.println(stCount + "S");
				System.out.println(blCount + "B");
			} else if (stCount == 3) {
				System.out.println("정답!!");
				break;
			}
		}
		scan.close();
	}
}

// ex) com : 1 2 3
// user : 1 9 8 => 1s
// user : 2 3 8 => 2b
// user : 1 3 2 => 1s 2b
// user : 1 2 5 => 2s
// user : 7 8 9 => out! (아무것도 안 맞으면)
