package day08;

import java.util.Arrays;
import java.util.Random;

public class Exam01 {

	Random ran = new Random();
	// 1. 랜덤 수를 리턴하는 메서드 (1~45)
	public int random() {
		int a = ran.nextInt(45) + 1;
		return a;
	}

	// 2. 중복 확인 메서드 : 배열에 정수가 있는 지 확인 (true or false)
	// - 매개변수 (배열, 랜덤정수)
	public boolean cheak(int arr[], int b) {
		
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == b) {
				return true;
			}
		}
		return false;
	}

	// 3. 배열을 매개변수로 받아 랜덤 수(1번 메서드 호출)를 중복X(2번 메서드 호출) 채워주는 메서드
	public int[] arr(int arr[]) {

		for (int i = 0; i < arr.length; i++) {
			int ran = random();
			if (cheak(arr, ran) == true) {
				i--;
			}
		}
		return arr;
	}

	// 4. 배열을 출력하는 메서드
	// - 사용자 번호 1 2 3 4 5 6
	// - 당첨 번호 1 2 3 4 5 6 [7]<= 보너스번호
	public void print(int a[]) {
		System.out.println(Arrays.toString(a));
	}

	// 5. 당첨을 확인하는 메서드 (리턴만 해도되고 바로 출력해도 됨)
	// - 사용자 번호, 당첨 번호를 받아서 등수를 리턴하는 메서드
	// - 6개 일치 = 1등 (순서 상관없이 숫자만, 보너스 제외)
	// - 5개 일치 + 보너스 일치 = 2등
	// - 5개 일치 = 3등
	// - 4개 일치 = 4등
	// - 3개 일치 = 5등
	// - 나머지는 꽝

	public static void main(String[] args) {
		Exam01 mathod = new Exam01();
		// 로또 만들기
		// - 사용자 번호 (6개) 자동
		// - 당첨 번호 (7개) 자동
		int user[] = new int[6];
		int lotto[] = new int[7];

		mathod.arr(user);
		mathod.arr(lotto);
		
		mathod.print(user);
		mathod.print(lotto);
	}

}
